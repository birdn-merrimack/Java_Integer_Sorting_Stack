Natalie Bird
CSC6301 - Project 5

----------
Command to run program:
	- java IntegerStackSorting.java
-----------
Javadoc command:
	javadoc -private IntegerStackSorting.java
-----------
No AI was used in creating this code.

-----------
Code Reuse:

Project 4 Code:

I reused my code from the CSC6301 Project 4 assignment and made the following changes:
- Renamed the public class 'Main' to 'IntegerStackSorting' in order to better convey the functionality for the .java file
- Swapped from using LinkedList<> to Stack<>
- Renamed the following methods:
	- 'getList()' to 'inputStack()' to better denote that this method uses user input to create a Stack<>
	- 'sortList()' to 'sortStack()'
	- 'printList()' to 'printStack()'
- Renamed the following variables: 
	- 'integerList' to 'integerStack' (method: inputStack())
	- 'listToSort' to 'stackToSort' (method: sortStack())
	- 'listToSort' to 'stackToPrint' (method: printStack())
	- 'inputList' to 'inputStack' (method: main())

- I added to the prompt asking for a list of numbers in inputStack() to inform users that any Double they enter will be rounded down to the nearest Integer.
- I was unhappy with the Exception catching pieces of 'inputStack()' (previously 'getList()' in my Project 4 code) as my program would still run through the other methods. In order to cut down on using unnecessary resources, I added a 'System.exit(0)' line to the Exception catch in 'inputStack()'.
- Added constructor IntegerStackSorting() in order to resolve a warning I was getting when running javadoc.
	- Java 126: Resolve warning: use of default constructor, which does not provide a comment
	- Selected Topics in IT: https://www.youtube.com/watch?v=n7aub-2Y8IQ

Version 2.0 Edits
- Added "\\n" to scanner object Delimiter
- Removed note about Doubles from scanner object prompt

-----------
Stack (Java SE 11 & JDK 11):
- Documentation for this utility may be found at: https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/Stack.html
- I used the Java Collection Stack<> utility in order to meet the 'stack' requirement of this project instead of creating my own LIFO stack code.
- In order to sort the Stack, I used the Stack.sort() method. By using "null" as the Comparator, .sort() defaults to sorting from least to greatest (or alphabetically A to Z).

-----------
List Iterator: 
- Documentation for this utility may be found at: https://docs.oracle.com/en/java/javase/11/docs/api/java.base/java/util/ListIterator.html
- I use the Java Collections ListIterator<> utility instead of using a do-while or for loop to iterate through the Stack<> passed in as a parameter to 'printStack()'.


