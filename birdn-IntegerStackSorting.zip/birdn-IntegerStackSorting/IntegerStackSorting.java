/**
 * CSC6301 - Project 5 - Stack and Collections Framework
 * 
 * Program prompts user to input a comma-delimited list of integers and stores the input as a Stack<>. Sorts the Stack from least to greatest and prints out the sorted Stack.
 * 
 * No AI was used to assist in writing this code.
 * 
 * @author Natalie Bird
 * @version 2.0
 * @since 1.0
*/

// Import Scanner, Stack, and ListIterator modules
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Stack;


/**
 * Method of program: IntegerStackSorting
 * Public methods are the constructor 'IntegerStackSorting()'
 * Private methods are inputStack(), sortStack(), and printStack().
 * 
 */
public class IntegerStackSorting {
    
    /**
     * Default constructor for IntegerStackSorting public class.
     * Intializes a new instance of the class.
     */
    public IntegerStackSorting() {
        // No initialization required.
    }

    /**
     * Uses a Scanner object to receive user input and parse it into a Stack of Integers.
     * Catches exceptions when Scanner object runs into an error (e.g. finds a String instead of an Integer) and prints out the exception.
     * Otherwise returns the Stack.
     * 
     * @return Stack (Integer)
     */
    private static Stack<Integer> inputStack() {
        // Scanner object to take user input: inputScanner. Uses "," as a delimiter until the last value which requires \\r for 'return' (aka Enter key).
        Scanner inputScanner = new Scanner(System.in).useDelimiter(",|\\r\\n");

        // Create a Stack<> class object from java.util.Stack to contain Integers inputted by user: integerStack.
        Stack<Integer> integerStack = new Stack<>();

        // Catch the NumberFormatException error thrown when a String is inputted.
        try {
            // Prompt user to input a list of Integers, delimited by commas.
            System.out.println("Enter a comma-delimited list of Integers without spaces (e.g. 1,5,-7,10,33,-16). When finished, press the 'Enter' key twice:\n") ;
            // Do-While to parse input and add to Stack
            do{
                // Capture next value in inputScanner string as a Double, convert to Integer, add it to integerStack
                integerStack.add((int) inputScanner.nextDouble());
            // Do the above operation so long as the Scanner object (inputScanner) has a Double followed by "," or "\r"
            } while (inputScanner.hasNextDouble());
            inputScanner.close();
   
        // Catch NumberFormatException, etc.
        } catch (Exception ohno) {
            System.out.println("Caught Error: " + ohno + "\nClosing inputScanner ... ");
            // Close the Scanner object
            inputScanner.close();
            System.exit(0);
        }

        // Return the Stack 'integerStack'
        return integerStack;

    }

    /**
     * Accepts a Stack of Integers and sorts it from least to greatest.
     * Returns sorted Stack.
     * 
     * @param stackToSort Stack (Integer)
     * @return Stack (Integer)
     */
    private static Stack<Integer> sortStack(Stack<Integer> stackToSort) {
        // If stackToSort has only 1 value, return it as it is already sorted. If not, call Stack<>.sort(). 'c:null' defaults the sort mechanism to using ascending numberical order.
        if (stackToSort.size() > 1) {
            stackToSort.sort(null);
        }
        // Return the now-sorted 'stackToSort'
        return stackToSort;
    }

    /**
     * Accepts a Stack of Integers and uses ListIterator to iterate through and print out the values.
     * Formats as a comma-delimited string.
     * 
     * @param stackToPrint Stack (Integer)
     */
    private static void printStack(Stack<Integer> stackToPrint) {
        // Create preliminary output string: output
        String output = "Sorted Stack:\n";
        // Create ListIterator for integerStack: it
        ListIterator<Integer> it = stackToPrint.listIterator();
        while (it.hasNext()) {
            output += it.next() + ",";
        }
        // Remove the last "," by taking a substring of 'ouput' up to the penultimate character
        output = output.substring(0, output.length()-1);
        // Print 'output'
        System.out.println(output);
    }

    /**
     * Main method of program.
     * - Calls 'inputStack()' which prompts for and receives a user-inputted Stack of numbers. Stores return as Stack (Integer): inputStack.
     * - Calls 'printStack()' on 'sortStack(inputStack)' to print out the sorted Stack. 'sortStack()' very simply sorts the Stack. 'printStack()' iterates through the Stack and prints out the values in a formatted String.
     * 
     * @param args Required for public static void main to run
     */
    public static void main(String[] args) {
        Stack<Integer> inputStack = inputStack();
        printStack(sortStack(inputStack));
    }   
}